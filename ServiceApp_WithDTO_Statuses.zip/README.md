# ServiceApp — ASP.NET Core Web API + MySQL

## ✅ Як запустити

1. Імпортуйте базу з SQL-файлу у MySQL Workbench (базу `service`)
2. Відкрийте файл `ServiceApp.sln` або `ServiceApp.csproj` у Visual Studio
3. Натисніть `Ctrl + F5` або `Запуск без відлагодження`
4. Swagger буде доступний на http://localhost:5000/swagger або https://localhost:5001/swagger